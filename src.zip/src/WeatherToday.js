import React from "react";

const WeatherToday = ({ cityName }) => <h1>{cityName}</h1>;

export default WeatherToday;
